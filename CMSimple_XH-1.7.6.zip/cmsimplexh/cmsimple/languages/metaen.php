<?php

$mtx['seperator']="Separator";
$mtx['external']="Name";
$mtx['link']="Validate links";
$mtx['org']="Original";
$mtx['urichar']="URL-Characters";
