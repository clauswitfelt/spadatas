<?php
$tpl_tx['text']['sitename_logobox']="<a href=\"./\" title=\"Home\"><img src='" . $pth['folder']['templateimages'] . "logo_default.png' alt='Logo'></a>";
$tpl_tx['text']['sitename_slogan']="CMSimple_XH Template";
$tpl_tx['text']['language_select']="<img src='" . $pth['folder']['templateimages'] . "gmi_language.svg' alt='Select language'><span>&nbsp;&nbsp;Select language</span>";
$tpl_tx['text']['legalnotice']="Legal Notice";
$tpl_tx['text']['privacy']="Privacy";
$tpl_tx['text']['mailform']="Mailform";
$tpl_tx['text']['modal-overlay']="Click to close";
$tpl_tx['text']['menu_button']="Menu & News";
$tpl_tx['text']['pagetools_to-top']="To top";
$tpl_tx['text']['footer_company-name']="Company";

 // Config languagemenu (select the display of the language menu)
$cf['language']['menu']="dd_longname"; // Options: flags|shortname|longname|flagsandshortname|flagsandlongname|dd_longname|dd_flagsandlongname (dd_=Dropdownmenu)
