<?php
$plugin_mcf['tinymce5']['init']="function:tinymce_getInits";
$plugin_mcf['tinymce5']['utf8_marker']="hidden";
$plugin_mcf['tinymce5']['CDN']="bool";   //"" = locally installed, "CDN" = CDN Variant 
$plugin_mcf['tinymce5']['CDN_src']="text";
