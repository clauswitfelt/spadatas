<?php

$script = '
<script>

function setLink(link){
    top.filebrowsercallback(link);
    top.filebrowserwindow.close();
}

</script>';
?>
