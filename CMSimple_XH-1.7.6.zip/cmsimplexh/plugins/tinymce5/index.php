<?php //just overwrite existing index.php
