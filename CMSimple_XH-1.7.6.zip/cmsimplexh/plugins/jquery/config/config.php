<?php

$plugin_cf['jquery']['version_core']="3.7.0";
$plugin_cf['jquery']['version_ui']="1.13.2";
$plugin_cf['jquery']['version_migrate']="jquery-migrate-3.4.1.min.js";
$plugin_cf['jquery']['load_migrate']="";
$plugin_cf['jquery']['autoload']="";
$plugin_cf['jquery']['autoload_libraries']="jQuery";
