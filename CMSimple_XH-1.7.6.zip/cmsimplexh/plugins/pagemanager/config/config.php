<?php

$plugin_cf['pagemanager']['verbose']="true";
$plugin_cf['pagemanager']['toolbar_show']="true";
$plugin_cf['pagemanager']['pagedata_attribute']="linked_to_menu";
$plugin_cf['pagemanager']['treeview_theme']="proton";
$plugin_cf['pagemanager']['treeview_animation']="200";

?>
