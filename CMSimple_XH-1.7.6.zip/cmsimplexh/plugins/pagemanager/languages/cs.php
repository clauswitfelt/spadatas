<?php

/*
 * Copyright (c) 2014 Oldnema
 *
 * This work is licensed under the GNU General Public License v3.
 */

$plugin_tx['pagemanager']['button_cancel']="Zrušit";
$plugin_tx['pagemanager']['button_delete']="Vymazat";
$plugin_tx['pagemanager']['button_ok']="OK";
$plugin_tx['pagemanager']['op_save']="Uložit";
$plugin_tx['pagemanager']['cf_pagedata_attribute']="Atributy PageData mohou být upraveny pomocí zaškrtávacích políček: \"linked_to_menu\" (viditelná v menu) nebo \"published\" (zveřejněno). Pro skrytí políček nechte prázdné.";
$plugin_tx['pagemanager']['cf_toolbar_show']="Zda bude zobrazen panel nástrojů.";
$plugin_tx['pagemanager']['cf_treeview_animation']="Doba otevření/zavření animace v ms. 0 znamená bez animace.";
$plugin_tx['pagemanager']['cf_treeview_theme']="Téma of tree view widget.";
$plugin_tx['pagemanager']['cf_verbose']="Zda chcete zobrazit informace a potvrzovací dialogy.";
$plugin_tx['pagemanager']['error_nesting']="Příliš hluboko vnořeno v úrovni stránek!";
$plugin_tx['pagemanager']['error_offending_extension']="Problém v rozšíření pomocí vlastní jQuery knihovny detekován (viz návod, kapitola \"Limitations\").";
$plugin_tx['pagemanager']['error_structure_confirmation']="Pokračujte!";
$plugin_tx['pagemanager']['error_structure_warning']="Chybná struktura stránek. Kontaktuje správce stránek!\r\nPokud budete pokračovat fixován Pagemanager_XH, což nemusí být to, co chcete.";
$plugin_tx['pagemanager']['menu_main']="Správa stránek";
$plugin_tx['pagemanager']['message_confirm_deletion']="Strana bude smazána včetně podstran!";
$plugin_tx['pagemanager']['message_confirm_leave']="*** ÚPRAVY NEBYLY ULOŽENY! ***\r\n\r\nPotvrďte uložení, jinak nebudou změny uloženy!\r\n";
$plugin_tx['pagemanager']['message_save_failure']="Struktura stránky nelze uložit do \"%s\"!";
$plugin_tx['pagemanager']['message_save_success']="Struktura stránky byla úspěšně uložena.";
$plugin_tx['pagemanager']['message_warning_leave']="Vaše nastavení bude ztraceno!";
$plugin_tx['pagemanager']['op_copy']="Kopírovat";
$plugin_tx['pagemanager']['op_cut']="Vystřihnout";
$plugin_tx['pagemanager']['op_remove']="Vymazat";
$plugin_tx['pagemanager']['op_paste']="Vložit";
$plugin_tx['pagemanager']['op_rename']="Přejmenovat";
$plugin_tx['pagemanager']['syscheck_extension']="Rozšíření \"%s\" načteno";
$plugin_tx['pagemanager']['syscheck_jquery']="jQuery4CMSimple plugin instalován";
$plugin_tx['pagemanager']['syscheck_phpversion']="PHP verze ≥ %s";
$plugin_tx['pagemanager']['syscheck_title']="Kontrola systému";
$plugin_tx['pagemanager']['syscheck_writable']="Adresář \"%s\" je zapisovatelný";
$plugin_tx['pagemanager']['syscheck_xhversion']="CMSimple_XH verze ≥ %s";
$plugin_tx['pagemanager']['treeview_loading']="Načítám....";
$plugin_tx['pagemanager']['treeview_new']="Nová strana";

?>
