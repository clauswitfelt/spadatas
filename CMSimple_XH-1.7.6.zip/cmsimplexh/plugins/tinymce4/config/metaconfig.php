<?php
$plugin_mcf['tinymce4']['init']="function:tinymce_getInits";
$plugin_mcf['tinymce4']['utf8_marker']="hidden";
$plugin_mcf['tinymce4']['CDN']="bool";   //"" = locally installed, "CDN" = CDN Variant 
$plugin_mcf['tinymce4']['CDN_src']="hidden"; //obsolete
