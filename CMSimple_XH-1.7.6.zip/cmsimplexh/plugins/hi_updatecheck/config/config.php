<?php

$plugin_cf['hi_updatecheck']['autocheck']="true";
$plugin_cf['hi_updatecheck']['autocheck_timeout']="3";
$plugin_cf['hi_updatecheck']['autocheck_notify']="All updates";
$plugin_cf['hi_updatecheck']['ignore']="filebrowser,meta_tags,page_params,tinymce,tinymce4,tinymce5";
