CKEDITOR.plugins.setLang('fontawesome', 'de', {
	title: 'Font Awesome einfügen'
});
