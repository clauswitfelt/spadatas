<?php

$plugin_tx['fa']['alt_logo']="Fort Awesome";
$plugin_tx['fa']['syscheck_fail']="Fehler";
$plugin_tx['fa']['syscheck_message']="Prüfe, dass %1\$s … %2\$s";
$plugin_tx['fa']['syscheck_phpversion']="die PHP-Version ≥ %s";
$plugin_tx['fa']['syscheck_success']="OK";
$plugin_tx['fa']['syscheck_title']="System-Prüfung";
$plugin_tx['fa']['syscheck_warning']="Warnung";
$plugin_tx['fa']['syscheck_writable']="„%s“ schreibbar ist";
$plugin_tx['fa']['syscheck_xhversion']="die CMSimple_XH-Version ≥ %s";
$plugin_tx['fa']['cf_require_auto']="Ob Font Awesome immer verfübar ist.";
$plugin_tx['fa']['cf_fontawesome_version']="Die zu verwendende Font Awesome Version. Die Editor-Plugins sind noch nicht mit Font Awesome 5 kompatibel.";
$plugin_tx['fa']['cf_fontawesome_shim']="Verbesserte Abwärtskompatibilität bei Verwendung von Font Awesome 5.";
